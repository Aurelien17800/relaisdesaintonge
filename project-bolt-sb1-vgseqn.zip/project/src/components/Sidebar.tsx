import React from 'react';
import { Car, Users, FileText, BarChart2, Settings } from 'lucide-react';

export default function Sidebar() {
  return (
    <div className="w-64 bg-gray-900 min-h-screen p-4 flex flex-col">
      <div className="mb-8">
        <h1 className="text-white text-xl font-bold">RELAIS DE SAINTONGE</h1>
      </div>
      
      <nav className="flex-1">
        <ul className="space-y-2">
          <li>
            <a href="#" className="flex items-center text-gray-300 hover:text-white p-2 rounded hover:bg-gray-800">
              <Car className="mr-3 h-5 w-5" />
              Véhicules
            </a>
          </li>
          <li>
            <a href="#" className="flex items-center text-gray-300 hover:text-white p-2 rounded hover:bg-gray-800">
              <Users className="mr-3 h-5 w-5" />
              Clients
            </a>
          </li>
          <li>
            <a href="#" className="flex items-center text-gray-300 hover:text-white p-2 rounded hover:bg-gray-800">
              <FileText className="mr-3 h-5 w-5" />
              Documents
            </a>
          </li>
          <li>
            <a href="#" className="flex items-center text-gray-300 hover:text-white p-2 rounded hover:bg-gray-800">
              <BarChart2 className="mr-3 h-5 w-5" />
              Statistiques
            </a>
          </li>
        </ul>
      </nav>
      
      <div className="mt-auto">
        <a href="#" className="flex items-center text-gray-300 hover:text-white p-2 rounded hover:bg-gray-800">
          <Settings className="mr-3 h-5 w-5" />
          Paramètres
        </a>
      </div>
    </div>
  );
}