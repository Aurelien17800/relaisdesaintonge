import React from 'react';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import VehicleList from './components/VehicleList';

// Mock data for demonstration
const mockStats = {
  totalVehicles: 24,
  soldThisMonth: 8,
  averageMargin: 2500,
  totalValue: 450000
};

const mockVehicles = [
  {
    id: '1',
    brand: 'Peugeot',
    model: '3008',
    year: 2020,
    mileage: 45000,
    vin: 'VF3MRHNS6KS123456',
    licensePlate: 'AB-123-CD',
    purchasePrice: 18000,
    additionalCosts: 500,
    sellingPrice: 21500,
    status: 'in_stock',
    photos: ['https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?auto=format&fit=crop&q=80&w=100&h=100'],
    maintenanceHistory: []
  },
  {
    id: '2',
    brand: 'Renault',
    model: 'Captur',
    year: 2021,
    mileage: 32000,
    vin: 'VF1RJB00X66123456',
    licensePlate: 'EF-456-GH',
    purchasePrice: 15000,
    additionalCosts: 300,
    sellingPrice: 17800,
    status: 'reserved',
    photos: ['https://images.unsplash.com/photo-1549317661-bd32c8ce0db2?auto=format&fit=crop&q=80&w=100&h=100'],
    maintenanceHistory: []
  }
] as const;

function App() {
  return (
    <div className="flex min-h-screen bg-gray-100">
      <Sidebar />
      <main className="flex-1">
        <Dashboard stats={mockStats} />
        <VehicleList vehicles={mockVehicles} />
      </main>
    </div>
  );
}

export default App;