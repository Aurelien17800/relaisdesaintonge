export interface Vehicle {
  id: string;
  brand: string;
  model: string;
  year: number;
  mileage: number;
  vin: string;
  licensePlate: string;
  purchasePrice: number;
  additionalCosts: number;
  sellingPrice: number;
  status: 'in_stock' | 'reserved' | 'sold';
  photos: string[];
  maintenanceHistory: MaintenanceRecord[];
}

export interface MaintenanceRecord {
  id: string;
  date: string;
  description: string;
  cost: number;
}

export interface Stats {
  totalVehicles: number;
  soldThisMonth: number;
  averageMargin: number;
  totalValue: number;
}